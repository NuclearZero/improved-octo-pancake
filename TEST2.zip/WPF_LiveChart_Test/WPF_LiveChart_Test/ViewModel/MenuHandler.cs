﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Input;
using System.Diagnostics;
using System.Windows;
using System.ComponentModel;
using WPF_LiveChart_Test.ViewModel.Commands;

namespace WPF_LiveChart_Test.ViewModel
{
    public class MenuHandler :INotifyPropertyChanged
    {

        public LoadChartCommand MyCommand { get; set; }
        public StackedBarGraphViewModel GraphOverall1 { get; set; }
       
        public MenuHandler()
        {
           // MyCommand = new LoadChartCommand(this);
           // GraphOverall1 = new StackedBarGraphViewModel();
        }

        #region
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyname)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyname));

        }
        #endregion Property Changed

        public void LoadChartCommand()
        {
            GraphOverall1.Visible = Visibility.Visible;
            OnPropertyChanged("Visible");
        }

    }

}