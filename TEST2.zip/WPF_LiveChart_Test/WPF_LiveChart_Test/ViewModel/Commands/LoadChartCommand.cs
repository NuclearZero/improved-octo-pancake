﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using WPF_LiveChart_Test.ViewModel;

namespace WPF_LiveChart_Test.ViewModel.Commands
{
    public class LoadChartCommand : ICommand
    {
        public StackedBarGraphViewModel Graph { get; set; }
        public LoadChartCommand(StackedBarGraphViewModel graph) 
        {
            this.Graph = graph;
        }

        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            Graph.LoadChartCommand();
        }
    }
}
