﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.ComponentModel;
using System.Windows;
using WPF_LiveChart_Test.ViewModel.Commands;
using WPF_LiveChart_Test.Graphs;
using LiveCharts;
using LiveCharts.Wpf;


namespace WPF_LiveChart_Test.ViewModel
{
    public class StackedBarGraphViewModel : INotifyPropertyChanged
    {
        public LoadChartCommand MyCommand { get; set; }
        private string texto;
        public string Texto
        {
            get { return texto; }
            set
            {
                OnPropertyChanged("Texto");
                texto = value;
            }
        }

        private Visibility visible;
        public Visibility Visible
        {
            get { return visible; }
            set
            {
                OnPropertyChanged("Visible");
                visible = value;
            }
        }
        /// <summary>
        /// Constructor
        /// </summary>
        public StackedBarGraphViewModel()
        {
            Texto = "AALLVVVVV SAAL";
            Visible = Visibility.Hidden;
            MyCommand = new LoadChartCommand(this); 

            seriesCollection = new SeriesCollection
            {
                new StackedColumnSeries
                {
                    Values = new ChartValues<double> {4, 5, 6, 8},
                    StackMode = StackMode.Values, // this is not necessary, values is the default stack mode
                    DataLabels = true
                },
                new StackedColumnSeries
                {
                    Values = new ChartValues<double> { 2, 5, 6, 7 },
                    StackMode = StackMode.Values,
                    DataLabels = true
                }
            };

            //adding series updates and animates the chart
            seriesCollection.Add(new StackedColumnSeries
            {
                Values = new ChartValues<double> { 6, 2, 7 },
                StackMode = StackMode.Values
            });

            //adding values also updates and animates
            seriesCollection[2].Values.Add(4d);

            Labels = new[] { "Chrome", "Mozilla", "Opera", "IE" };
            Formatter = value => value + " Mill";
        }
        /// <summary>
        /// Functions and everything else
        /// </summary>
        public SeriesCollection seriesCollection { get; set; }
        public string[] Labels { get; set; }
        public Func<double, string> Formatter { get; set; }

        public void LoadChartCommand()
        {
            visible = Visibility.Visible;
            OnPropertyChanged("Visible");
        }

        #region
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyname)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyname));

        }
        #endregion Property Changed
        
    }

}
