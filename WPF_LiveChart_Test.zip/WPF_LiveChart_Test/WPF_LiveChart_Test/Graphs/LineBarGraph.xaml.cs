﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LiveCharts;
using LiveCharts.Wpf;

namespace WPF_LiveChart_Test.Graphs
{
    /// <summary>
    /// Interaction logic for LineBarGraph.xaml
    /// </summary>
    public partial class LineBarGraph : UserControl
    {
        public SeriesCollection seriesCollection { get; set; }
        public Func<double, string> Formatter { get; set; }
        public string[] Labels { get; set; }

        public LineBarGraph()
        {
            InitializeComponent();
            
            seriesCollection = new SeriesCollection
            {
                new LineSeries
                {
                    Title = "Production",
                    Values = new ChartValues<double> { 11, 56, 42,50 }
                },
               new ColumnSeries
                {
                    Title = "Completions",
                    Values = new ChartValues<double> { 10, 50, 39, 50 }
                }
                
            };
            seriesCollection.Add(new ColumnSeries
            {
                Title = "Production",
                Values = new ChartValues<double> { 11, 56, 42, 50 }
            });

            seriesCollection.Add(new LineSeries
            {
                Title = "Completions",
                Values = new ChartValues<double> { 10, 50, 39, 50 }
            });
            Labels = new[] { "January", "February","March","April" };
            Formatter = value => value.ToString("N");
            DataContext = this;
        }
        
        
    }
}
