﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Input;
using WPF_LiveChart_Test.ViewModel.Commands;

namespace WPF_LiveChart_Test.ViewModel
{
    public class MenuHandler : INotifyPropertyChanged
    {
        
        public LoadChartCommand MyCommand { get; set; }
        public StackedBarGraphViewModel GraphOverall1 { get; set; }
        

        public MenuHandler()
        {
            MyCommand = new LoadChartCommand(this);
        }
        #region
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyRaised(string propertyname)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyname));
            }

        }
        #endregion Property Changed

        public void LoadChartCommand()
        {
            Console.WriteLine("Hola");
        }
    }
    
}