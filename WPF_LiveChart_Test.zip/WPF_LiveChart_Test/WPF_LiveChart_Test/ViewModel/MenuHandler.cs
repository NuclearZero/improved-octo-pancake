﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace WPF_LiveChart_Test.ViewModel
{
    public class MenuHandler : INotifyPropertyChanged
    {
        public StackedBarGraphViewModel GraphOverall1 { get; set; }
        public RadioButton OverallBtn { get; set; }
        private bool _checked;
        public bool Checked 
        {
            get
            {
                return _checked;
            }
            set 
            {
                _checked = value;
                OnPropertyRaised("Checked");
            }
        }

        public MenuHandler()
        {


            OverallBtn = new RadioButton();

            if (OverallBtn.IsChecked == false)
            {
                GraphOverall1 = new StackedBarGraphViewModel();
            }

        }
        #region
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyRaised(string propertyname)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyname));
            }

        }
        #endregion Property Changed
    }
}