﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using WPF_LiveChart_Test.ViewModel;

namespace WPF_LiveChart_Test.ViewModel.Commands
{
    public class LoadChartCommand : ICommand
    {
        public MenuHandler MenuHandler { get; set; }
        public LoadChartCommand(MenuHandler menuHandler) 
        {
            MenuHandler = menuHandler;
        }

        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            MenuHandler.LoadChartCommand();
        }
    }
}
